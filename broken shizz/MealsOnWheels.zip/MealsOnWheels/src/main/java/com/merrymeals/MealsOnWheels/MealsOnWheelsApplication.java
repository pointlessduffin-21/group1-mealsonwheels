package com.merrymeals.MealsOnWheels;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MealsOnWheelsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MealsOnWheelsApplication.class, args);
	}

}
