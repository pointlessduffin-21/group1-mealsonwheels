package com.Group1.MealsOnWheels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MealsOnWheelsApplicationTests {

	@Test
	void contextLoads() {
	}

}
